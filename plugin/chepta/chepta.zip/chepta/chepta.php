<?php
/*
Plugin Name: chepta
Plugin URI:
Description: Demo of Plugin Options Page
Version: 1.0
Author: LWHH
Author URI: https://dipto.me
License: GPLv2 or later
Text Domain: chepta
*/
// Register Custom Post Type chepta
function create_chepta_cpt() {

	$labels = array(
		'name' => _x( 'chepta', 'Post Type General Name', 'chepta-post' ),
		'singular_name' => _x( 'chepta', 'Post Type Singular Name', 'chepta-post' ),
		'menu_name' => _x( 'chepta', 'Admin Menu text', 'chepta-post' ),
		'name_admin_bar' => _x( 'chepta', 'Add New on Toolbar', 'chepta-post' ),
		'archives' => __( 'chepta Archives', 'chepta-post' ),
		'attributes' => __( 'chepta Attributes', 'chepta-post' ),
		'parent_item_colon' => __( 'Parent chepta:', 'chepta-post' ),
		'all_items' => __( 'All Custom Posts', 'chepta-post' ),
		'add_new_item' => __( 'Add New chepta', 'chepta-post' ),
		'add_new' => __( 'Add New', 'chepta-post' ),
		'new_item' => __( 'New chepta', 'chepta-post' ),
		'edit_item' => __( 'Edit chepta', 'chepta-post' ),
		'update_item' => __( 'Update chepta', 'chepta-post' ),
		'view_item' => __( 'View chepta', 'chepta-post' ),
		'view_items' => __( 'View Custom Posts', 'chepta-post' ),
		'search_items' => __( 'Search chepta', 'chepta-post' ),
		'not_found' => __( 'Not found', 'chepta-post' ),
		'not_found_in_trash' => __( 'Not found in Trash', 'chepta-post' ),
		'featured_image' => __( 'Featured Image', 'chepta-post' ),
		'set_featured_image' => __( 'Set featured image', 'chepta-post' ),
		'remove_featured_image' => __( 'Remove featured image', 'chepta-post' ),
		'use_featured_image' => __( 'Use as featured image', 'chepta-post' ),
		'insert_into_item' => __( 'Insert into chepta', 'chepta-post' ),
		'uploaded_to_this_item' => __( 'Uploaded to this chepta', 'chepta-post' ),
		'items_list' => __( 'Custom Posts list', 'chepta-post' ),
		'items_list_navigation' => __( 'Custom Posts list navigation', 'chepta-post' ),
		'filter_items_list' => __( 'Filter Custom Posts list', 'chepta-post' ),
	);
	$args = array(
		'label' => __( 'chepta', 'chepta-post' ),
		'description' => __( '', 'chepta-post' ),
		'labels' => $labels,
		'menu_icon' => 'dashicons-yes',
		'supports' => array('title', 'editor', 'excerpt', 'thumbnail'),
		'taxonomies' => array(),
		'public' => true,
		'show_ui' => true,
		'show_in_menu' => true,
		'menu_position' => 5,
		'show_in_admin_bar' => true,
		'show_in_nav_menus' => true,
		'can_export' => true,
		'has_archive' => true,
		'hierarchical' => false,
		'exclude_from_search' => false,
		'show_in_rest' => true,
		'publicly_queryable' => true,
		'capability_type' => 'post',
	);
	register_post_type( 'chepta', $args );

}
add_action( 'init', 'create_chepta_cpt', 0 );

function chepta_single_template($file){
	global $post;
	if ('chepta' == $post->post_type) {
		$file_path = plugin_dir_path(__FILE__).'cpt/cpt_template.php';
		$file = $file_path;

	}
	return $file;
}
add_filter('single_template','chepta_single_template');